// a)
CREATE TABLE User_profile (
    id  INT NOT NULL PRIMARY KEY auto_increment,
    username VARCHAR(50) NOT NULL,
    password1 VARCHAR(255) NOT NULL,
    fullname VARCHAR(255) NOT NULL,
  	avatar VARCHAR(255),
  	birthday TIMESTAMP,
   	created_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP 
);
CREATE TABLE Friends (
  id INT PRIMARY KEY AUTO_INCREMENT,
  sender_id INT NOT NULL,
  receiver_id INT NOT NULL, 
  status ENUM('pending', 'accepted', 'rejected'),
  created_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP 

);
CREATE TABLE Message (
  id INT PRIMARY KEY AUTO_INCREMENT,
  sender_id INT NOT NULL,
  receiver_id INT NOT NULL,
  type ENUM('text', 'image', 'video', 'file') NOT NULL,
  content VARCHAR(255),
  status ENUM('send', 'pending_read', 'read'), 
  created_time DATETIME DEFAULT CURRENT_TIMESTAMP 
);

// b)
INSERT INTO User_profile(userName, password1, fullname, avatar, birthday)
VALUES ('tung', 'abc', 'do phu tung', 'ca chep', '2015-12-25 00:00:00'),
	  ('tuan', 'abc', 'do phu tuan', 'ech', '2022-03-22'),
    ('dung', 'abc', 'do phu dung', 'ca cham', '2022-03-20'),
    ('hung', 'abc', 'do phu hung', 'ca chuoi', '2022-03-12');

INSERT INTO Friends(sender_id, receiver_id, status)
VALUES (1, 2, 'pending');
INSERT INTO Friends(sender_id, receiver_id, status)
VALUES (2, 3, 'rejected');
INSERT INTO Friends(sender_id, receiver_id, status)
VALUES (3, 4, 'accepted');
INSERT INTO Friends(sender_id, receiver_id, status)
VALUES (4, 1, 'pending');

INSERT INTO Message(sender_id, receiver_id, type, content, status)
VALUES (1, 2, 'text', 'ABC', 'read');
INSERT INTO Message(sender_id, receiver_id, type, content, status)
VALUES (2, 3, 'text', 'GBC', 'pending_read');
INSERT INTO Message(sender_id, receiver_id, type, content, status)
VALUES (3, 4, 'text', 'Ab', 'read');
INSERT INTO Message(sender_id, receiver_id, type, content, status)
VALUES (4, 1, 'text', 'Kj', 'send');

// C.1)
SELECT id, username, fullname, avatar
FROM User_profile
WHERE id = 2 OR id = 3;
// c.2) 
(SELECT p.username, p.fullname, p.avatar
FROM User_profile  p 
LEFT OUTER JOIN Friends f ON p.id = f.receiver_id
WHERE (p.id != 2) AND (f.status='accepted') AND (f.sender_id=2) ) UNION ALL
(
SELECT p.username, p.fullname, p.avatar
FROM User_profile  p 
LEFT OUTER JOIN Friends f ON p.id = f.sender_id
WHERE (p.id != 2) AND (f.status='accepted') AND (f.receiver_id=2) 
) ;

// c.3)
SELECT id as message_id, sender_id, receiver_id, type, status, content, created_time
FROM Message
WHERE sender_id = 2 AND receiver_id = 3;

// c.4
SELECT B.friend_id, B.message_id, A.type, A.status, A.content, A.sender_id, A.created_time
FROM Message as A
JOIN (
SELECT  receiver_id as friend_id, MAX(id) as message_id
FROM Message
WHERE sender_id = 2
GROUP BY receiver_id) as B 
ON A.id = B.message_id;

// c.5
SELECT U.id as ID, COUNT(F.id) as NumberFriend
FROM User_profile as U 
JOIN Friends as F 
ON (U.id = F.sender_id) OR (U.id = F.receiver_id)
WHERE status = 'accepted'
GROUP BY U.id
ORDER BY NumberFriend DESC LIMIT 10;