// Em viết bằng Javascript
class Student {
  constructor(name, age, math, physical, chemistry) {
    this.name = name;
    this.age = age;
    this.math = math;
    this.physical = physical;
    this.chemistry = chemistry;
    this.avg ;
    this.rank ;
  }
  // b. Tính điểm trung bình(avg), và xếp hạng (rank) cho mỗi Student
  calAvg = function () {
    this.avg = (this.math + this.physical + this.chemistry) / 3;
    return this.avg;
  };
  calRank = function () {
    let avg = this.avg();
    if (avg >= 8) {
      this.rank = "GIOI";
    } else if (avg < 8 && avg >= 6.5) {
      this.rank = "KHA";
    } else if (avg < 6.5 && avg >= 5) {
      this.rank = "TB";
    } else {
      this.rank = "YEU";
    }
  };
}
class ManageStudent {
  constructor() {
    this.students = [];
  }
  addStudent(student) {
    this.students.push(student);
  }
  // c. Viết phương thức tìm kiếm 1 student có name là parameter của method đó.
  searchByName(name) {
    for (let element of this.students) {
      if (element.name == name) {
        return element;
      }
    }
  }

  // d. Viết thương thức lấy ra danh sách Student có rank là GIOI.
  listExcellentStudent() {
    return this.students.filter((element) => {
      return element.rank() == "GIOI";
    });
  }

  // e.Sắp xếp students tăng dần theo AlphaB. Nếu tên giống nhau thì sắp xếp tăng dần theo điểm TB.
  sortArray() {
    let array = this.students;
    
    // bubble sort
    for (let i = 0; i < (array.length); i++) {
      for (let j = 0; j < (array.length-i-1); j++) {
        let compareName = (array[j].name.localeCompare(array[j+1].name));
        if( compareName > 0 ){
          [array[j], array[j+1]] = [array[j+1], array[j]];
        }
      }
    };
    console.log(array);
  }
}
// a) Tạo 8 học sinh gồm, mỗi học sinh gồm: name, age,  math, physical, chemistry.
const student1 = new Student("Thang", 12, 8, 10, 10);
const student2 = new Student("An", 11, 5, 5, 2);
const student3 = new Student("Kien", 13, 9, 5, 6);
const student4 = new Student("An", 15, 7, 5, 6);
const student5 = new Student("Hoa", 16, 8, 5, 10);
const student6 = new Student("Binh", 18, 8, 3, 6);
const student7 = new Student("Huong", 11, 9, 10, 8);
const student8 = new Student("An", 12, 10, 9, 9);

const manageStudent = new ManageStudent();
manageStudent.addStudent(student1);
manageStudent.addStudent(student2);
manageStudent.addStudent(student3);
manageStudent.addStudent(student4);
manageStudent.addStudent(student5);
manageStudent.addStudent(student6);
manageStudent.addStudent(student7);
manageStudent.addStudent(student8);

manageStudent.sortArray();
// console.log("Thang".localeCompare("Thbng"));
