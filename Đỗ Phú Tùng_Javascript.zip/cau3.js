// Em viết bằng Javascript
const string = "Bknqw eucnks Acfn naw ee k";
const stringLonger= "asfdABCsfaasafsa dfasdfasdfa sdfasfasf";

class MyString {
  // a. Tính tổng bảng mã ASCCI của các ký tự trong chuỗi.
  sumChar(string) {
    let sum = 0;
    for (let ch of string) {
      sum += ch.codePointAt(0);
    }
    console.log(sum);
  }
  // b. Tính tổng bảng mã ASSI của các ký tự in hoa trong chuỗi.
  sumUppercaseChar(string) {
    let sum = 0;
    for (let ch of string) {
      let valueOfChar = ch.codePointAt(0);
      if (valueOfChar >= 65 && valueOfChar <= 90) {
        sum += valueOfChar;
      }
    }
    console.log(sum);
  }
  // c.
  showTimesOfChar(string, n) {
    let existedChar = [];
    let timeOfChar = [];
    for (let ch of string) {
      if (!existedChar.includes(ch)) {
        existedChar.push(ch);
        timeOfChar.push(1);
      } else {
        let index = existedChar.indexOf(ch);
        timeOfChar[index] += 1;
      }
    }
    existedChar.forEach((element, index) => {
      if (timeOfChar[index] > n) {
        console.log(element, timeOfChar[index]);
      }
    });
  }
  //d. Cho hai chuỗi s1 và s2, tìm chuỗi con dài nhất có trong s1 và s2
  compare2String(string1, string2){
    let longerString =  (string1.length > string2.length)? string1 : string2;
    console.log(longerString);
  }
}
let myString = new MyString();
myString.sumChar(string);
myString.sumUppercaseChar(string);
myString.showTimesOfChar(string, 2);
myString.compare2String(string, stringLonger);