// Em viết bằng Javascript
const array = [1,2, 3, 5,4, 1, 3, 4,5, 4, 5,9,7,0,11, 13,10,23,90]
class Cau4 {
  // a. Tính tổng các số trong mảng
  sumArray(array) {
    let sum = array.reduce((sum, curr) => {
      return (sum += curr);
    }, 0);
    console.log(sum);
  }

  // b. Tính tổng các số nguyên tố trong mảng
  checkNguyenTo(n) {
    if (n < 2) {
      return false;
    }
    for (let i = 0; i < n / 2; i++) {
      if (n % i == 0) {
        return false;
      }
    }
    return true;
  }
  sumNguyenTo(array) {
    let sumary = array.reduce((sum, curr) => {
      if (this.checkNguyenTo(curr)) {
        return (sum += curr);
      }
    });
    console.log(sumary);
  }
  // c. Tìm và in ra bộ 3 liên tiếp nhau sao có: arrInt[i] + arrInt[i+1] = arrInt[i+2]
  findGroupOfNumber(array) {
    let groupOfNumber = [];
    for (let index = 0; index < array.length; index++) {
      if (array[index] + array[index + 1] == array[index + 2]) {
        groupOfNumber.push([array[index], array[index + 1], array[index + 2]]);
      }
    }
    console.log(groupOfNumber);
  }
  // d. Tìm và in ra dãy con dài nhất có tổng = S.

}
const cau4 = new Cau4();
cau4.sumArray(array);
cau4.findGroupOfNumber(array);
