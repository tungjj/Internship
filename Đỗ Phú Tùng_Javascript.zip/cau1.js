// Em viết bằng Javascript
// Câu 1: Viết chương trình tính biêủ thức sau: S(x,n) = x + x 1 + x 2 + … + xn (5 điểm)
const x = 2;
const n = 3;

class Bai1 {
  constructor(x, n) {
    this.x = x;
    this.n = n;
  }
  sumary() {
    let sum = this.x;

    for (let index = 1; index <= this.n; index++) {
      sum += Math.pow(this.x, index);
    }
    return sum;
  }
}
const bai1 = new Bai1(x, n);
console.log(bai1.sumary());
